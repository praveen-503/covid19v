import { Component, OnInit } from '@angular/core';
// import Chart from 'chart.js';
import { DashboardService } from 'src/app/services/dashboard.service';
@Component({
  selector: 'app-side-charts',
  templateUrl: './side-charts.component.html',
  styleUrls: ['./side-charts.component.scss']
})
export class SideChartsComponent implements OnInit {

  isDaily : boolean= true;
  constructor(public dashService: DashboardService) {
  //  this.view = [innerWidth / 1.3, 150];
  }
  // onResize(event) {
  //   this.view = [event.target.innerWidth / 1.35, 150];
  // }
  ngOnInit() {
  }
  changeData(name) {
    if (name == 'daily') {
      this.isDaily = true;
    }
    else{
      this.isDaily = false;
    }

  }
  onSelect(data) {
    console.log(data);
  }
  view: any[] = [370, 150];

  // options for the chart
  showXAxis = true;
  showYAxis = true;
  gradient = false;
  showLegend = true;
  showXAxisLabel = true;
  xAxisLabel = 'Dates';
  showYAxisLabel = true;
  showGridLines =  false;
  yAxisLabel = ['Confirmed','Recovered','Deceased'];

  timeline = true;

  colorScheme = [
  {domain: ['#ff929d', '#87CEFA', '#FA8072', '#FF7F50', '#90EE90', '#9370DB']},
  {domain: ['#93f3a9', '#9370DB', '#FA8072', '#FF7F50', '#90EE90', '#9370DB']},
  {domain: ['#ffe493', '#87CEFA', '#FA8072', '#FF7F50', '#90EE90', '#9370DB']},
];

  //pie
  showLabels = true;


}
