import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { StateData, DailyAndCummulativ, Daily, Cumulative } from '../models/state.model';
import { element } from 'protractor';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  stateName: String;
  statesOrDistricts: String;
  latestCasesCount;
  hospitalLatestData;
  stateDayWiseData: Daily[];
  stateCumulativeWiseData: Cumulative[];
  statesData: StateData[];
  dailyCumulativeData: DailyAndCummulativ[];
  topFiveStates;
  constructor(private http: HttpClient) {
    this.getDailyCumulativeData();
    this.getIndiaDayWise();
    //this.getLatestIndiaCases();
    this.getHospitalList();
  }
  getTotalCountsByStateCode(code) {
    if (code == 'IN') {
      this.statesOrDistricts = 'States';
    }
    else{
      this.statesOrDistricts = 'Districts';
    }
    this.statesData.forEach(ele => {
      if (ele.stateCode == code) {
        this.stateName = ele.name;
        this.latestCasesCount = ele;
      }
    })
    console.log("Latest Cases", this.latestCasesCount)
  }

  getAllStateWiseData(code) {
    this.dailyCumulativeData.forEach(element => {
      if (element.stateCode == code) {
        this.stateDayWiseData = element.daily;
        this.stateCumulativeWiseData = element.cumulative
      }
    })
  }

  getIndiaStateWiseData() {
    return this.http.get<any>(environment.apiUrl + '/indiastatewisedata')
      .subscribe(result => {
        this.statesData = result.StatesData;
        this.topFiveStates = result.top5States;
        this.getTotalCountsByStateCode('IN')

      },
        err => (console.log(err)));

  }

  getDailyCumulativeData() {
    // dailyCumulativecharts
    return this.http.get<any>(environment.apiUrl + '/dailyCumulativecharts')
      .subscribe(result => {
        this.dailyCumulativeData = result as DailyAndCummulativ[];
        // console.log('daily cumulative data',this.dailyCumulativeData);
        this.getAllStateWiseData('IN');

      }, err => {
        console.log(err);
      })

  }
  getLatestIndiaCases() {
    this.http.get(environment.apiUrl + '/india-latest').subscribe(res => {
      this.latestCasesCount = res;
    },
      err => {
        console.log(err);
      });
  }
  getHospitalList() {
    this.http.get(environment.apiUrl + '/hospitalList').subscribe(res => {
      this.hospitalLatestData = res;
    },
      err => {
        console.log(err);
      });
  }

  getIndiaDayWise() {
    return this.http.get<any>(environment.apiUrl + '/india-actual-daywise');
  }

  getTopStates() {
    return this.http.get<any>(environment.apiUrl + '/india-statewise-data');

  }

  getIndiaPredectionData() {
    return this.http.get<any>(environment.apiUrl + '/india-predict-data');
  }
}
