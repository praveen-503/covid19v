export const environment = {
  production: true,
  apiUrl : 'https://covid19nodejs.azurewebsites.net',
};
